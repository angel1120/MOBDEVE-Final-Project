package com.mobdeve.finalproject;

import static androidx.core.app.ActivityCompat.startActivityForResult;
import static androidx.core.content.ContextCompat.startActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class SavedPlacesAdapter extends RecyclerView.Adapter<SavedPlacesAdapter.MyViewHolder> {

    private Context context;
    private Activity activity;
    private ArrayList id, label;

    public static final int ADD_EDIT_REQUEST_CODE = 1;

    SavedPlacesAdapter(Context context, Activity activity, ArrayList id, ArrayList label){
        this.context = context;
        this.id = id;
        this.label = label;
        this.activity = activity;
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.savedplaces_rows, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SavedPlacesAdapter.MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        //    holder.id_txt.setText(String.valueOf(id.get(position)));
        holder.label_txt.setText(String.valueOf(label.get(position)));

        // Set click listener for the "More" button
        holder.btnMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Open a menu when the button is clicked
                PopupMenu popupMenu = new PopupMenu(context, holder.btnMore);

                // Use the context of the holder to get the correct resources
                MenuInflater inflater = popupMenu.getMenuInflater();
                inflater.inflate(R.menu.actions, popupMenu.getMenu());


                // Set menu item click listener
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(android.view.MenuItem item) {
                        int option = item.getItemId();
                        if (option == R.id.editOption) {
                            // Handle delete action

                            Intent intent = new Intent(context, EditSavedPlaceActivity.class);

                        //    Intent intent = new Intent(context, AddEditSavedPlaceActivity.class);
                        //    Toast.makeText(context,"EditText Button is Clicked", Toast.LENGTH_SHORT).show();
                        //    Intent intent = new Intent(context, EditSavedPlaceActivity::class.java);
                            // Pass necessary data through intent
                        //    startActivity(intent);
                        //    Toast.makeText(context,String.valueOf(label.get(position)), Toast.LENGTH_SHORT).show();
                            intent.putExtra("id", String.valueOf(id.get(position)));
                            intent.putExtra("label", String.valueOf(label.get(position)));

                            activity.startActivityForResult(intent, ADD_EDIT_REQUEST_CODE);

                        //    activity.startActivity(intent);

                        //   activity.startActivityForResult(intent, 1);

                            return true;
                        }
                        // Add more cases for other menu items if needed
                        else {
                            return false;
                        }
                    }
                });

                popupMenu.show();


            }
        });


    }

    @Override
    public int getItemCount() {
        return id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        LinearLayout mainLayout;
        TextView id_txt, label_txt;

        ImageView btnMore;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            label_txt = itemView.findViewById(R.id.tvSavedPlace);
            btnMore = itemView.findViewById(R.id.btnMore);


        }
    }
}
