package com.mobdeve.finalproject

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.PopupMenu
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class SavedPlacesActivity : AppCompatActivity() {

//    private lateinit var viewBinding: SavedPlacesBinding

    lateinit var myDB: DatabaseHandler
//    var data = ArrayList<String>()

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnAdd: FloatingActionButton
//    private lateinit var myDB: DatabaseHandler
    private var id = ArrayList<String>()
    private var label = ArrayList<String>()
    private lateinit var savedPlacesAdapter: SavedPlacesAdapter
    val ADD_EDIT_REQUEST_CODE = 1


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.saved_places)

        recyclerView = findViewById(R.id.rvSavedPlaces)
        btnAdd = findViewById(R.id.fabAddPlace)
    /*    btnAdd.setOnClickListener({
            var intent = Intent(applicationContext, AddEditSavedPlaceActivity::class.java)
            this.startActivity(intent)
        }) */

        btnAdd.setOnClickListener {
            val intent = Intent(applicationContext, AddEditSavedPlaceActivity::class.java)
            startActivityForResult(intent, ADD_EDIT_REQUEST_CODE)
        }

        myDB = DatabaseHandler(this@SavedPlacesActivity)

        id = ArrayList()
        label = ArrayList()

        storeDataInArrays()

        savedPlacesAdapter = SavedPlacesAdapter(this@SavedPlacesActivity,this@SavedPlacesActivity,  id, label)

        recyclerView.adapter = savedPlacesAdapter
        recyclerView.layoutManager = LinearLayoutManager(this@SavedPlacesActivity)


    }



    fun storeDataInArrays() {
        val cursor = myDB.readAllData()
        if (cursor!!.count == 0) {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show()
        } else {
            while (cursor.moveToNext()) {
                id.add(cursor.getString(0))
                label.add(cursor.getString(1))

            }

        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ADD_EDIT_REQUEST_CODE && resultCode == RESULT_OK) {
            // Data has been added or edited, update the RecyclerView
            updateRecyclerView()
        }
    }

    private fun updateRecyclerView() {
        id.clear()
        label.clear()
        storeDataInArrays()
        savedPlacesAdapter.notifyDataSetChanged()
    }


/*    fun showPopup(v: View){
        val popup = PopupMenu(v.context, v)
        val inflater = popup.menuInflater
        inflater.inflate(R.menu.actions, popup.menu)

    /*    popup.setOnMenuItemClickListener {
            when(it.itemId){
                R.id.editOption->{
                    Toast.makeText(v.context,"EditText Button is Clicked", Toast.LENGTH_SHORT).show()
                    true
                }

                else -> true
            }
        } */

        popup.show()
    /*    val pop = PopupMenu::class.java.getDeclaredField("mPopup")
        pop.isAccessible = true
        val menu = pop.get(pop)
        menu.javaClass.getDeclaredMethod("setForceShowIcon", Boolean::class.java).invoke(menu, true) */
    } */


}


