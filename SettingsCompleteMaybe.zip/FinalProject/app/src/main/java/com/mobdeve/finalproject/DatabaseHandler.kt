package com.mobdeve.finalproject

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast


class DatabaseHandler(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    private val context: Context? = context

    companion object {
        private const val DATABASE_VERSION = 1 // Database version
        private const val DATABASE_NAME = "SavedPlacesDatabase.db" // Database name
        private const val TABLE_NAME = "saved_places" // Table Name

        //All the Columns names
        private const val COLUMN_ID = "_id"
        private const val COLUMN_LABEL = "label"
    //    private const val KEY_IMAGE = "image"
    //    private const val KEY_DESCRIPTION = "description"
    //    private const val KEY_DATE = "date"
    //    private const val COLUMN_LOCATION = "location"
    //    private const val COLUMN_LATITUDE = "latitude"
    //    private const val COLUMN_LONGITUDE = "longitude"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        //creating table with fields
    /*    val query = ("CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_LABEL + " TEXT,"
                + COLUMN_LOCATION + " TEXT,"
                + COLUMN_LATITUDE + " TEXT,"
                + COLUMN_LONGITUDE + " TEXT)") */

        val query = ("CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_LABEL + " TEXT)")

        db?.execSQL(query)

    //    val contentValues = ContentValues()
    //    contentValues.put(COLUMN_LABEL, "Hyunjin Love of My Life")
    //    contentValues.put(COLUMN_LOCATION, "My Heart")
    //    contentValues.put(COLUMN_LATITUDE, "32000")
    //    contentValues.put(COLUMN_LONGITUDE, "325")

    //    db?.insert(TABLE_NAME, null, contentValues)
    //    db?.close()

    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db!!.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addSavedPlace(label:String){
        val db: SQLiteDatabase = writableDatabase

        val contentValues = ContentValues()

    //    val title = "hwanghyunjin"

        contentValues.put(COLUMN_LABEL, label)
        val result: Long = db.insert(TABLE_NAME, null, contentValues)
        if (result == -1L) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Added Successfully", Toast.LENGTH_SHORT).show()
        }


    }

    fun readAllData(): Cursor? {
        val query = "SELECT * FROM $TABLE_NAME"
        val db = this.readableDatabase

        var cursor: Cursor? = null
        if (db != null) {
            cursor = db.rawQuery(query, null)
        }
        return cursor
    }

    fun updateData(row_id: String, label: String?) {
        val db = this.writableDatabase
        val cv = ContentValues()
        cv.put(COLUMN_LABEL, label)
        val result = db.update(TABLE_NAME, cv, "_id=?", arrayOf<String>(row_id)).toLong()
        if (result == -1L) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Updated Successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    //Function to insert a Saved Place details to SQLite Database.
/*    fun addHappyPlace(savedPlace: SavedPlaceModel): Long {
        val db = this.writableDatabase

        val contentValues = ContentValues()
        contentValues.put(COLUMN_LABEL, savedPlace.label)
        contentValues.put(COLUMN_LOCATION, savedPlace.location)
        contentValues.put(COLUMN_LATITUDE, savedPlace.latitude)
        contentValues.put(COLUMN_LONGITUDE, savedPlace.longitude)

        // Inserting Row //this is one a button click
        val result = db.insert(TABLE_NAME, null, contentValues)

        db.close() // Closing database connection
        return result

    } */




    //Function to read all the list of Happy Places data which are inserted.
//    @SuppressLint("Range")
/*    fun getHappyPlacesList(): ArrayList<SavedPlaceModel> {

        // A list is initialize using the data model class in which we will add the values from cursor.
        val savedPlaceList: ArrayList<SavedPlaceModel> = ArrayList()

        val selectQuery = "SELECT  * FROM $TABLE_NAME" // Database select query

        val db = this.readableDatabase

        try {
            val cursor: Cursor = db.rawQuery(selectQuery, null)
            if (cursor.moveToFirst()) {
                do {
                    val place = SavedPlaceModel(
                        cursor.getInt(cursor.getColumnIndex(COLUMN_ID)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_LABEL)),
                        cursor.getString(cursor.getColumnIndex(COLUMN_LOCATION)),
                        cursor.getDouble(cursor.getColumnIndex(COLUMN_LATITUDE)),
                        cursor.getDouble(cursor.getColumnIndex(COLUMN_LONGITUDE))
                    )
                    savedPlaceList.add(place)

                } while (cursor.moveToNext())
            }
            cursor.close()
        } catch (e: SQLiteException) {
            db.execSQL(selectQuery)
            return ArrayList()
        }
        return savedPlaceList
    } */

}