package com.mobdeve.finalproject

import android.app.Activity
import com.mobdeve.finalproject.R
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import com.mobdeve.finalproject.databinding.ActivityStartBinding
import java.io.IOException


class StartActivity: AppCompatActivity() {

    lateinit var mediaPlayer: MediaPlayer
    lateinit var vibrator: Vibrator

    var soundBoolean: Boolean = true
    var vibrationBoolean: Boolean = true

    val PICK_FILE = 99

    private lateinit var viewBinding: ActivityStartBinding

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)

        viewBinding = ActivityStartBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        this.mediaPlayer = MediaPlayer.create(this, R.raw.test_sound)

//        mediaPlayer.start()
//        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
//        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
/*        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager =
                getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        } */

    //    val button = findViewById<Button>(R.id.btnClick)

    //    val intent = intent
    //    val audio = intent.getStringExtra("EXTRA_LAYOUT", 0)

        val intent = intent
        val audio = intent.getStringExtra("EXTRA_AUDIO")
    //    val distance = intent.getBooleanExtra("EXTRA_DISTANCE")
        val proximity = intent.getBooleanExtra("EXTRA_PROXIMITY", false)

    //    if (vibration = )
        Log.d("stream megaverse: ", proximity.toString())

    //    createMediaPlayer(audio!!.toUri())

        if (audio != null) {
            Log.d("this is the shit: ", audio)
            createMediaPlayer(audio!!.toUri())
        }
        else {
            Log.d("this is the shit: ", "booohoo")
        }

    //    mediaPlayer.setDataSource(applicationContext, audio!!.toUri())
    //    mediaPlayer.prepare()

    //    releaseMediaPlayer()

    //    mediaPlayer = MediaPlayer.create(this, R.raw.test_sound)
    //    mediaPlayer = MediaPlayer.create(this, audio!!.toUri())



        viewBinding.btnClick.setOnClickListener {
            // Check if the MediaPlayer is null or not playing
            if (mediaPlayer != null && !mediaPlayer!!.isPlaying) {
                // Start playing the sound
                mediaPlayer!!.start()
            }

        /*    if (vibrationBoolean){
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    // Deprecated in API 26
                    vibrator.vibrate(500)
                }
            } */
        }


        viewBinding.btnGo.setOnClickListener({
            val intent = Intent(applicationContext, MapsMainActivity::class.java)
            intent.putExtra("STATUS", "no_destination")
            this.startActivity(intent)
        })

        viewBinding.btnSettings.setOnClickListener({
            val intent = Intent(applicationContext, SettingsActivity::class.java)
            this.startActivity(intent)

            // stop media player
        })



    /*    viewBinding.btnClick.setOnClickListener({

            mediaPlayer.start()

            if (vibrationBoolean){
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    // Deprecated in API 26
                    vibrator.vibrate(500)
                }
            }
        }) */

    }

    private fun releaseMediaPlayer() {
        mediaPlayer?.apply {
            if (isPlaying || isLooping) {
                stop()
            }
            release()
        }

    }

    // Create a new MediaPlayer with the given audio source
    private fun createMediaPlayer(uri: Uri) {
        releaseMediaPlayer() // Release the current MediaPlayer

        mediaPlayer = MediaPlayer()
        mediaPlayer?.apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            try {
                setDataSource(applicationContext, uri)
                prepare()
                start()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseMediaPlayer()
    }


    /* override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
         super.onActivityResult(requestCode, resultCode, data)

         if (requestCode == PICK_FILE && resultCode == Activity.RESULT_OK) {
             data?.data?.let { uri ->
                 createMediaPlayer(uri)
             }
         }
     }

     private fun createMediaPlayer(uri: Uri) {
         try {
             mediaPlayer = MediaPlayer()

             mediaPlayer.setAudioAttributes(
                 AudioAttributes.Builder()
                     .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                     .setUsage(AudioAttributes.USAGE_MEDIA)
                     .build()
             )

             mediaPlayer.setDataSource(applicationContext, uri)
             mediaPlayer.prepare()
             mediaPlayer.start()

             // You can add other configurations or callbacks here as needed

         } catch (e: Exception) {
             e.printStackTrace()
         }
     } */


}