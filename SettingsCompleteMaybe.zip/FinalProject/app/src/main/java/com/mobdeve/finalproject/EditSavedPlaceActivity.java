package com.mobdeve.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class EditSavedPlaceActivity extends AppCompatActivity {
    EditText labelInput;
    Button save;
    String id, label;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_saved_place);

//        labelInput = findViewById(R.id.etLabelEdit);
        save = findViewById(R.id.btnSaveEdit);
        labelInput = findViewById(R.id.etLabelEdit);

        id = getIntent().getStringExtra("id");
        label = getIntent().getStringExtra("label");
        labelInput.setText(label);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //And only then we call this
                DatabaseHandler myDB = new DatabaseHandler(EditSavedPlaceActivity.this);
                label = labelInput.getText().toString().trim();
                myDB.updateData(id, label);

                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);
                finish();

            //    startActivityForResult(intent, ADD_EDIT_REQUEST_CODE)
            //    setResult(RESULT_OK);
            //    finish();

            }
        });

    //    getAndSetIntentData();
        //First we call this
   //     getAndSetIntentData();

/*        //Set actionbar title after getAndSetIntentData method
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle(label);
        } */

/*        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //And only then we call this
                DatabaseHandler myDB = new DatabaseHandler (EditSavedPlaceActivity.this);
                label = labelInput.getText().toString().trim();
                myDB.updateData(id, label);
            }
        }); */


    }

/*    void getAndSetIntentData(){

        if(getIntent().hasExtra("label")){
            //Getting Data from Intent
        //    id = getIntent().getStringExtra("id");
            label = getIntent().getStringExtra("label");

            //Setting Intent Data
            labelInput.setText(label);

            Log.d("stev", label);
        }else{
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    } */

}
